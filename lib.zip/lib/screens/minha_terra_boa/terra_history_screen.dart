
import 'package:flutter/material.dart';

class TerraHistoryScreen extends StatelessWidget {
  const TerraHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Minha Terra HistoryScreen'),
      ),
      body: const Center(
        child: Text('Tela TerraHistoryScreen em construção'),
      ),
    );
  }
}
