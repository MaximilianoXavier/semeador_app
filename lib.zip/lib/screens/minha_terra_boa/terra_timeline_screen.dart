
import 'package:flutter/material.dart';

class TerraTimelineScreen extends StatelessWidget {
  const TerraTimelineScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Minha Terra TimelineScreen'),
      ),
      body: const Center(
        child: Text('Tela TerraTimelineScreen em construção'),
      ),
    );
  }
}
