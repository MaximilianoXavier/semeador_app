
class Missao {
  final String titulo;
  final String descricao;
  final String referencia;

  Missao({
    required this.titulo,
    required this.descricao,
    required this.referencia,
  });
}
